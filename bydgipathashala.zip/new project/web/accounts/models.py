from django.db import models

# Create your models here.

class Student(models.Model):
    name = models.CharField(max_length=50)
    f_name = models.CharField(max_length=100)
    address= models.CharField(max_length=100)
    phone=  models.CharField(max_length=50)
    join_date  = models.CharField(max_length=50)
    out_date = models.CharField(max_length=50) 

    def __str__(self):
        return self.name

class Devotees(models.Model):
    name = models.CharField(max_length=50)
    amount = models.IntegerField()
    item = models.CharField(max_length=50)
    date = models.CharField(max_length=50)
    # phone = models.CharField(max_length=50)

    def __str__(self):
        return self.name
 

class Account(models.Model):
    sino = models.CharField(max_length=50)
    date=models.DateTimeField(auto_now_add=True, null=True)
    name= models.CharField(max_length=50)
    debit = models.IntegerField()
    credit= models.IntegerField()
    ballance=models.IntegerField()
    
    def __str__(self):
        return self.name