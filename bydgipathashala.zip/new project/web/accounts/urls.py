from django.urls import path
from . import views

urlpatterns = [

	path('',views.index,name="index"),
    path('devotees/',views.devotees,name="devotees"),
    path('account/',views.account,name="account"),
    path('display_students/', views.display_students, name="display_students"),
    path('display_devotees/', views.display_devotees, name="display_devotees"),
    path('display_account/', views.display_account, name="display_account"),
    path('add_student', views.add_student, name="add_student"),
    path('add_devotees', views.add_devotees, name="add_devotees"),
    path('add_account', views.add_account, name="add_account"),
    path('student/edit_item<int:pk>/', views.edit_student, name='edit_student'),
    path('student/delete<int:pk>/', views.delete_student, name='delete_student'),
    path('devotees/edit_item<int:pk>/', views.edit_devotees, name='edit_devotees'),
    path('devotees/delete<int:pk>/', views.delete_devotees, name='delete_devotees'),
    path('account/edit_item<int:pk>/', views.edit_account, name='edit_account'),
    path('account/delete<int:pk>/', views.delete_account, name='delete_account'),
]