from django.shortcuts import render,redirect,get_object_or_404
from .forms import StudentForm
from .forms import DevoteesForm
from .forms import AccountForm
from .models import Student
from .models import Devotees
from .models import Account
# Create your views here.


# def home(request):
# 	all_members = Member.objects.all
# 	return render(request,'home.html', {'all':all_members})

def home(request):
	return render(request, 'home.html')


def index(request):
    return render(request, 'index.html')
    
def devotees(request):
    return render(request, 'devotees.html')

def account(request):
    return render(request, 'account.html')

def display_students(request):
    items = Student.objects.all()
    context = {
        'items': items,
         'header': 'Student',
    }
    return render(request, 'index.html', context)


def display_devotees(request):
    items1 = Devotees.objects.all()
    context = {
        'items1': items1,
        'header': 'Devotees',
    }
    return render(request, 'devotees.html', context)

def display_account(request):
    items = Account.objects.all()
    context = {
        'items': items,
         'header': 'Account',
    }
    return render(request, 'account.html', context)

def add_item(request, cls):
    if request.method == "POST":
        form = cls(request.POST)

        if form.is_valid():
            form.save()
            return redirect('display_students')
    else:
        form = cls()
        return render(request, 'add_new.html', {'form' : form})

def add_student(request):
    return add_item(request, StudentForm)

def add_item(request, cls):
    if request.method == "POST":
        form = cls(request.POST)

        if form.is_valid():
            form.save()
            return redirect('display_devotees')
    else:
        form = cls()
        return render(request, 'add_new.html', {'form' : form})

def add_devotees(request):
    return add_item(request, DevoteesForm)

def add_item(request, cls):
    if request.method == "POST":
        form = cls(request.POST)

        if form.is_valid():
            form.save()
            return redirect('display_account')
    else:
        form = cls()
        return render(request, 'add_new.html', {'form' : form})

def add_account(request):
    return add_item(request, AccountForm)

def edit_item(request, pk, model, cls):
    item = get_object_or_404(model, pk=pk)

    if request.method == "POST":
        form = cls(request.POST, instance=item)
        if form.is_valid():
            form.save()
            return redirect('devotees')
    else:
        form = cls(instance=item)

        return render(request, 'edit_item.html', {'form': form})


def edit_student(request, pk):
    return edit_item(request, pk, Student, StudentForm)

def edit_devotees(request, pk):
    return edit_item(request, pk, Devotees, DevoteesForm)

def edit_account(request, pk):
    return edit_item(request, pk, Account, AccountForm)


def delete_student(request, pk):

    template = 'index.html'
    Student.objects.filter(id=pk).delete()

    items = Student.objects.all()

    context = {
        'items': items,
    }

    return render(request, template, context)



def delete_devotees(request, pk):

    template = 'devotees.html'
    Devotees.objects.filter(id=pk).delete()

    items = Devotees.objects.all()

    context = {
        'items': items,
    }
    return render(request, template, context)
    

def delete_account(request, pk):

    template = 'index.html'
    Account.objects.filter(id=pk).delete()

    items = Account.objects.all()

    context = {
        'items': items,
    }

    return render(request, template, context)
    
