from django import forms
from .models import Student
from .models import Devotees
from .models import Account
from .models import *



class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = '__all__'

class DevoteesForm(forms.ModelForm):
    class Meta:
        model = Devotees
        fields = '__all__'

class AccountForm(forms.ModelForm):
    class Meta:
        model = Account
        fields = '__all__'
