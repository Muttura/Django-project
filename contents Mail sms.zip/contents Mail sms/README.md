# Django-Contact-Form-That-Sends-Emails
Basic dry project that sends django email via contact form. 
